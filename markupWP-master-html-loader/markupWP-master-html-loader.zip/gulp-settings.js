const devDir = 'dev';
const publicDir = 'public';

module.exports = {
	publicDir,
	devDir,
	assetsDir: `${devDir}/assets`,
	imagesDir: {
		entry: `${publicDir}/images`,
		output: `${publicDir}/images`
	},
	scssDir: {
		entry: `${devDir}/scss`,
		output: `${publicDir}/css`,
		mainFileName: 'style',
		mainFileOutput: publicDir
	},
	htmlDir: {
		entry: devDir,
		output: publicDir
	},
	jsDir: {
		entry: `${devDir}/js`,
		output: `${publicDir}/js`
	},
	jsES6: {
		entry: `${devDir}/js/es6`,
		names: ['main']
	}
};
