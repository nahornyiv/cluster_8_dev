## install project
```
$ npm install
```
## start project
```
$ gulp
```
##before sending the project to QA
```
gulp dist
```